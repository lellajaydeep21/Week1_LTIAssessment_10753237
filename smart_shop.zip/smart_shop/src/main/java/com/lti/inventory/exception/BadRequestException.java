package com.lti.inventory.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BadRequestException extends RuntimeException
{
	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = 1724688309695540471L;
	
	public BadRequestException(String message)
	{
		super(message);
	}
	
	public BadRequestException(String message, Throwable cause)
	{
		super(message, cause);
	}
}