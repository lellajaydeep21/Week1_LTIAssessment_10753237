package com.lti.inventory.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.inventory.entity.Product;
import com.lti.inventory.repository.InventoryRepository;

@Service
public class InventoryService {
	
	@Autowired
	InventoryRepository inventoryRepository;
	
	public Product getProductById(Long id) {
		return inventoryRepository.findProductById(id);
	}

	public Product getProductByName(String name) {
		return inventoryRepository.findProductByName(name);
	}
	
	public List<Product> getProducts(String category, String name) {
		if(name==null) {
			return inventoryRepository.findProductByCategory(category);
		} else {
			Product product = inventoryRepository.findProductByName(name);
			if(product==null) {
				return null;
			}
			return Arrays.asList(product);	
		}
	}
	
	public Product addProduct(Product product) {
		return inventoryRepository.save(product);
	}

	public void deleteProduct(Long id) {
		inventoryRepository.deleteById(id);
	}

	public void updateProduct(Long id, Product product) {
		Product productById = inventoryRepository.findProductById(id);
		if(productById!=null) {
			productById.setName(product.getName());
			productById.setCategory(product.getCategory());
			productById.setStock(product.getStock());
			productById.setUnitPrice(product.getUnitPrice());
			productById.setRating(product.getRating());
			inventoryRepository.flush();
		}
	}
}
