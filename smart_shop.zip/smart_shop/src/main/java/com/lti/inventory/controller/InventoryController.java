package com.lti.inventory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lti.inventory.entity.Product;
import com.lti.inventory.exception.BadRequestException;
import com.lti.inventory.exception.ResourceNotFoundException;
import com.lti.inventory.service.InventoryService;

@RestController
@RequestMapping("/api")
public class InventoryController {
	
	@Autowired
	InventoryService inventoryService;
	
	@RequestMapping(value = "/greet", method = RequestMethod.GET)
	public String getMessage() {
		return "Hello!";
	}
	
	@RequestMapping(value = "/getProducts/{id}", method = RequestMethod.GET)
	public ResponseEntity<Product> getProduct(@PathVariable Long id) {
		try {
			Product product = inventoryService.getProductById(id);
			if(product!=null)
				return new ResponseEntity<>(product,HttpStatus.OK);
			else 
				throw new ResourceNotFoundException("Product Not Found.");
		}catch(Exception e) {
			throw e;
		}
	}
	
	@RequestMapping(value = "/getProducts", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> getProductByCategory(@RequestParam(required=false) String category, @RequestParam(required=false) String name ) {
		if((name==null && category==null) || (name!=null && category!=null)) {
			throw new BadRequestException("Bad Request");
		}
		
		List<Product> products = inventoryService.getProducts(category,name);
		if(products==null || products.isEmpty()) {
			throw new ResourceNotFoundException("Product Not Found.");
		} else {
			return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
		}
	}
	
	@RequestMapping(value = "/deleteProducts/{id}", method = RequestMethod.DELETE)
	public void deleteProduct(@PathVariable Long id) {
		inventoryService.deleteProduct(id);
	}
	
	@RequestMapping(value = "/updateProducts/{id}", method = RequestMethod.PUT)
	public void updateProduct(@PathVariable Long id, @RequestBody Product product) {
		inventoryService.updateProduct(id, product);
	}
	
	@RequestMapping(value = "/addProducts", method = RequestMethod.POST)
	public Product addProduct(@RequestBody Product product) {
		return inventoryService.addProduct(product);
	}
}
