package com.lti.inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.lti.inventory.entity.Product;

@Repository
public interface InventoryRepository extends JpaRepository<Product, Long> {
	
	public Product findProductById(Long id);

	public Product findProductByName(String name);
	
	public List<Product> findProductByCategory(String name);

}
